import './App.css';
import Login from './components/Login';
import SignUp from './components/SignUp';

function App() {
  return (
    // <div className="text-13 h-screen px-4 py-8 bg-gradient-to-b from-white to-pink-500">
    //   {/* <button type="button" class="bg-gradient-to-r from-yellow-500 to-pink-500 hover:from-pink-500 hover:to-yellow-500 ...">
    //     Hover me
    //   </button> */}
    //   <h1>Hello World</h1>
    // </div>
    
    <Login/>
    // <SignUp/>


    

  );
}

export default App;
